var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a4f46894762e53533f9b99bf78a34ae51", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931", [
      [ "Status", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931aec53a8c4f07baed5d8825072c89799be", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931addbb78f293dfd6f43cd03ed85ad03286", null ],
      [ "Status", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931aec53a8c4f07baed5d8825072c89799be", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931addbb78f293dfd6f43cd03ed85ad03286", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a4f46894762e53533f9b99bf78a34ae51", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931", [
      [ "Status", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931aec53a8c4f07baed5d8825072c89799be", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931addbb78f293dfd6f43cd03ed85ad03286", null ],
      [ "Status", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931aec53a8c4f07baed5d8825072c89799be", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1p.html#a1767ae9ef5f93fad75de4a24b2013931addbb78f293dfd6f43cd03ed85ad03286", null ]
    ] ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479a34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479a34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#a9368bd66a16d508ff4f5671562e6858e", null ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479a34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#af76d7992802eab221bfb3b8ada010479a34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1n.html#a9368bd66a16d508ff4f5671562e6858e", null ]
];
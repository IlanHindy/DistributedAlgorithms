var class_distributed_algorithms_1_1_list_merge_1_1_present_data =
[
    [ "PresentData", "class_distributed_algorithms_1_1_list_merge_1_1_present_data.html#a9078a59e9558e601ed663ec09abf6941", null ],
    [ "indexInExsist", "class_distributed_algorithms_1_1_list_merge_1_1_present_data.html#a1765a83ae06b6b29bb21142731d8a65e", null ],
    [ "indexInNew", "class_distributed_algorithms_1_1_list_merge_1_1_present_data.html#a45ecdd591d42d3501addaabc1a381c78", null ],
    [ "attribute", "class_distributed_algorithms_1_1_list_merge_1_1_present_data.html#afb29f3bc5404e3e8a474c4ce29b8e677", null ]
];
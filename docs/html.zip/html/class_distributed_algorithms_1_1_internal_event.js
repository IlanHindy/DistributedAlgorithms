var class_distributed_algorithms_1_1_internal_event =
[
    [ "DummyForInternalEvent", "class_distributed_algorithms_1_1_internal_event_1_1_dummy_for_internal_event.html", null ],
    [ "InternalEventComps", "class_distributed_algorithms_1_1_internal_event.html#a2fe831dff39f84e7797e475455a08435", [
      [ "EventAction", "class_distributed_algorithms_1_1_internal_event.html#a2fe831dff39f84e7797e475455a08435ad28a0070f6ef6c36099dfc863f72f969", null ]
    ] ],
    [ "InternalEvent", "class_distributed_algorithms_1_1_internal_event.html#ac267e5d9d6288a202fe72690180f06f9", null ],
    [ "InternalEvent", "class_distributed_algorithms_1_1_internal_event.html#afdbe391fe34c500f75e09cb27d16f707", null ],
    [ "InternalEventDelegate", "class_distributed_algorithms_1_1_internal_event.html#a4992bda7c06f8287223f639c9af96850", null ],
    [ "Perform", "class_distributed_algorithms_1_1_internal_event.html#ab92b995d3e4b877fb61c8a15f5aa652b", null ],
    [ "MethodsListPrms", "class_distributed_algorithms_1_1_internal_event.html#a6a1a4e7f72b19e99a6b004345df4e514", null ],
    [ "AddMethod", "class_distributed_algorithms_1_1_internal_event.html#a3017fe0bb281cf4edaf84ad9f6162bbf", null ],
    [ "MethodComboBoxPrms", "class_distributed_algorithms_1_1_internal_event.html#afebc8192b9a3ec36251f7695138b3bfa", null ]
];
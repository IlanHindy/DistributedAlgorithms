var class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1c =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1c.html#a11adf8ac339d7e69048186f3c3e9ba43", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1c.html#a903785989eeda1650a9e91b9c6af47ec", null ]
];
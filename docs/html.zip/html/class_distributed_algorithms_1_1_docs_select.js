var class_distributed_algorithms_1_1_docs_select =
[
    [ "SelectSource", "class_distributed_algorithms_1_1_docs_select.html#a502702144c4f804bea2659d42d06d8f2", [
      [ "Source", "class_distributed_algorithms_1_1_docs_select.html#a502702144c4f804bea2659d42d06d8f2af31bbdd1b3e85bccd652680e16935819", null ],
      [ "Processed", "class_distributed_algorithms_1_1_docs_select.html#a502702144c4f804bea2659d42d06d8f2ae6f641ae8ac72385a9556588b0cac77c", null ],
      [ "PseudoCode", "class_distributed_algorithms_1_1_docs_select.html#a502702144c4f804bea2659d42d06d8f2a5983519cb3771c3eb8566fa510e9c5ab", null ]
    ] ],
    [ "Data", "class_distributed_algorithms_1_1_docs_select.html#a4bdf675b289fc5422f4b1d7d3b544014", [
      [ "Subject", "class_distributed_algorithms_1_1_docs_select.html#a4bdf675b289fc5422f4b1d7d3b544014ac7892ebbb139886662c6f2fc8c450710", null ],
      [ "Algorithm", "class_distributed_algorithms_1_1_docs_select.html#a4bdf675b289fc5422f4b1d7d3b544014a4afa80e77a07f7488ce4d1bdd8c4977a", null ],
      [ "Type", "class_distributed_algorithms_1_1_docs_select.html#a4bdf675b289fc5422f4b1d7d3b544014aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "File", "class_distributed_algorithms_1_1_docs_select.html#a4bdf675b289fc5422f4b1d7d3b544014a0b27918290ff5323bea1e3b78a9cf04e", null ]
    ] ],
    [ "SelectResult", "class_distributed_algorithms_1_1_docs_select.html#a14437c49fd318d6b0658f6c7d7512530", [
      [ "Quit", "class_distributed_algorithms_1_1_docs_select.html#a14437c49fd318d6b0658f6c7d7512530a0d82790b0612935992bd564a17ce37d6", null ],
      [ "Cancel", "class_distributed_algorithms_1_1_docs_select.html#a14437c49fd318d6b0658f6c7d7512530aea4788705e6873b424c65e91c2846b19", null ],
      [ "Open", "class_distributed_algorithms_1_1_docs_select.html#a14437c49fd318d6b0658f6c7d7512530ac3bf447eabe632720a3aa1a7ce401274", null ],
      [ "Save", "class_distributed_algorithms_1_1_docs_select.html#a14437c49fd318d6b0658f6c7d7512530ac9cc8cce247e49bae79f15173ce97354", null ]
    ] ],
    [ "DocsSelect", "class_distributed_algorithms_1_1_docs_select.html#afd34870d7200cb39d3c03ec459a24312", null ],
    [ "ListStr", "class_distributed_algorithms_1_1_docs_select.html#a2685139084f56095973bf02ccd9c10df", null ],
    [ "ListFiles", "class_distributed_algorithms_1_1_docs_select.html#a1b8dbf02b5c5f12336557a2430c8a073", null ],
    [ "Button_Quit_Click", "class_distributed_algorithms_1_1_docs_select.html#abd231c4e1a88af7646112b5b6d8b6716", null ],
    [ "Button_Select_Click", "class_distributed_algorithms_1_1_docs_select.html#a22858fe3d38bb434aa3bf5ca896593ab", null ],
    [ "EndSelectionForNew", "class_distributed_algorithms_1_1_docs_select.html#af6757ae0bc5a980a1b61a1c735c74694", null ],
    [ "result", "class_distributed_algorithms_1_1_docs_select.html#a4a82e4f8c19e266700e218648a9a0695", null ],
    [ "data", "class_distributed_algorithms_1_1_docs_select.html#af4a40ebef0f40de8abbd6940993da089", null ],
    [ "selectSource", "class_distributed_algorithms_1_1_docs_select.html#a75ef1e79be565f2ecc1fb321973d626e", null ],
    [ "fileExtension", "class_distributed_algorithms_1_1_docs_select.html#a060cec7647f6b22bf1f0686bb1686d0e", null ],
    [ "pathKey", "class_distributed_algorithms_1_1_docs_select.html#a67669e8066b4d9a89875cef474a9dc66", null ],
    [ "filesKey", "class_distributed_algorithms_1_1_docs_select.html#a12d50770e2aefd8d830c9f3de39e8048", null ],
    [ "subject", "class_distributed_algorithms_1_1_docs_select.html#a966b4aab7fa28d0aeee7b02d9c2505ef", null ],
    [ "algorithm", "class_distributed_algorithms_1_1_docs_select.html#ad2730330f9b82b1e030ffe6ca7c0e2bd", null ],
    [ "fileSelected", "class_distributed_algorithms_1_1_docs_select.html#acb48166156263fb5eb0a29a387471c21", null ]
];
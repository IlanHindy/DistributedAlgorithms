var class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#a5fea7b1ce5fc52bd3cfc52605ebc361c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28f", [
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28fa30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Received", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28faac5bb077c33753116b5e91ff1766e7bc", null ],
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28fa30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Received", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28faac5bb077c33753116b5e91ff1766e7bc", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#a5fea7b1ce5fc52bd3cfc52605ebc361c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28f", [
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28fa30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Received", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28faac5bb077c33753116b5e91ff1766e7bc", null ],
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28fa30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Received", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1p.html#aa28f1020e257769b975672a1abb4a28faac5bb077c33753116b5e91ff1766e7bc", null ]
    ] ]
];
var class_distributed_algorithms_1_1_internal_events =
[
    [ "DummyForInternalEvent", "class_distributed_algorithms_1_1_internal_events_1_1_dummy_for_internal_event.html", null ],
    [ "InternalEvents", "class_distributed_algorithms_1_1_internal_events.html#a4309ebbaca8042ee6f30c193fb28e870", null ],
    [ "InternalEvents", "class_distributed_algorithms_1_1_internal_events.html#af537412478b7cfa83085091dae491548", null ],
    [ "InternalEventDelegate", "class_distributed_algorithms_1_1_internal_events.html#a0ba04ea3f32cbfe0e1d48be47c2a0408", null ],
    [ "Activate", "class_distributed_algorithms_1_1_internal_events.html#ac7f305c59b26bc59775ef8c1ba117c26", null ],
    [ "MethodsListPrms", "class_distributed_algorithms_1_1_internal_events.html#af345f9eb6c3be2496df5cc9214477d2e", null ],
    [ "AddMethod", "class_distributed_algorithms_1_1_internal_events.html#a32226d412704b27c26ba02977d1f2c90", null ],
    [ "MethodComboBoxPrms", "class_distributed_algorithms_1_1_internal_events.html#a396efdcec896dc3b74aef850ea9e7366", null ]
];
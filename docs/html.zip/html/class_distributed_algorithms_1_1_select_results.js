var class_distributed_algorithms_1_1_select_results =
[
    [ "selection", "class_distributed_algorithms_1_1_select_results.html#a9a9acb2369810e26d99c290d4553453d", null ],
    [ "selectionText", "class_distributed_algorithms_1_1_select_results.html#a114ae7fb2fb6a7175a8c897daa1ec6cf", null ]
];
var class_distributed_algorithms_1_1_element_window_prms =
[
    [ "newValueControlPrms", "class_distributed_algorithms_1_1_element_window_prms.html#ae9cdf3ea6bd7e06627e79013f5207201", null ],
    [ "existingValueText", "class_distributed_algorithms_1_1_element_window_prms.html#adb6e6e1dfa60c06b9977a8fa2f4b3cf1", null ],
    [ "keyText", "class_distributed_algorithms_1_1_element_window_prms.html#a6a7a524f1584718193b6c6f20438d45c", null ],
    [ "typeString", "class_distributed_algorithms_1_1_element_window_prms.html#adf6e3f2eaa79bc574788bcd46b1c7123", null ]
];
var class_distributed_algorithms_1_1_font =
[
    [ "Font", "class_distributed_algorithms_1_1_font.html#a97f39c1264b5766f1ff4adc97389efea", null ],
    [ "Font", "class_distributed_algorithms_1_1_font.html#ac187047059016ace2ffc3df347e7fcae", null ],
    [ "SetFont", "class_distributed_algorithms_1_1_font.html#ab7d5046556fa20ab21775ac586aa9639", null ],
    [ "SetFontAndDimensions", "class_distributed_algorithms_1_1_font.html#ac26fdd33130391956b24cf69bfe8ddeb", null ],
    [ "fontFamily", "class_distributed_algorithms_1_1_font.html#a821e4fd91913ec72f33204dc4e282719", null ],
    [ "fontSize", "class_distributed_algorithms_1_1_font.html#ad0a50a3ae4e2fb53e64b2fbab9797e1d", null ],
    [ "fontStyle", "class_distributed_algorithms_1_1_font.html#a495aff584efd1d68c8cc5eeeb79e6a7b", null ],
    [ "fontWeight", "class_distributed_algorithms_1_1_font.html#a07f249cc5ec4d9903d2511050e9a707e", null ],
    [ "margin", "class_distributed_algorithms_1_1_font.html#aaba3e79a5bc87c4969b0ee7347c3da76", null ],
    [ "alignment", "class_distributed_algorithms_1_1_font.html#a14d24beded524acbe19e86d1d6ce4f85", null ],
    [ "forColor", "class_distributed_algorithms_1_1_font.html#a938779e42d4e70c7fcd16417d58fa9e4", null ],
    [ "backColor", "class_distributed_algorithms_1_1_font.html#a9403cce84a19e2a114f10b052d5ab806", null ],
    [ "wrap", "class_distributed_algorithms_1_1_font.html#a245637550d61ceb2f58b8c7e8e67bf26", null ]
];
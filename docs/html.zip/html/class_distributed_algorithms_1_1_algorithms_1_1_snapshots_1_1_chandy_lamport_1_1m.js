var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m =
[
    [ "report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3", [
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a8c489d0946f66d17d73f26366a4bf620", null ]
    ] ],
    [ "marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0", [
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0a8c489d0946f66d17d73f26366a4bf620", null ]
    ] ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a1484252e00b26e888c412a0659a27a8e", null ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385d", [
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ],
    [ "report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3", [
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a9af99b8ecc496ac14d4e408933fd01b3a8c489d0946f66d17d73f26366a4bf620", null ]
    ] ],
    [ "marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0", [
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a20ec2d30bb13e8edca2bd2a828d731f0a8c489d0946f66d17d73f26366a4bf620", null ]
    ] ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a1484252e00b26e888c412a0659a27a8e", null ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385d", [
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1m.html#a92021cbb5d92719205a80e4c5da1385da024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ]
];
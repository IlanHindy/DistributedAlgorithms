var class_distributed_algorithms_1_1_base_algorithm_messages =
[
    [ "Comps", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a489f61c7889bea09a9706333e1a08408", [
      [ "Type", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a489f61c7889bea09a9706333e1a08408aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Name", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a489f61c7889bea09a9706333e1a08408a49ee3087348e8d44e1feda1917443987", null ],
      [ "Fields", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a489f61c7889bea09a9706333e1a08408aa4ca5edd20d0b5d502ebece575681f58", null ],
      [ "Targets", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a489f61c7889bea09a9706333e1a08408a91fadc5613280f76b916f1fd236e43e9", null ]
    ] ],
    [ "AddMessage", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a753f01bd845a1ea3aa454250266e2516", null ],
    [ "EmptyMessageData", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a391979dd7c0e48f3ccf4ff65551715e4", null ],
    [ "Send", "class_distributed_algorithms_1_1_base_algorithm_messages.html#aefba8f5cc133885393cd2f8fb44546d5", null ],
    [ "MessageListPrms", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a090cbf718e1a2c5961c6c74a1d558695", null ],
    [ "IntListPrms", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a975de9aae6bede143794d7162ae190e0", null ],
    [ "CreateProcessIdAttribute", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a1ea5cbc997efda66752c5e66320d1b75", null ],
    [ "CheckIfProcessExists", "class_distributed_algorithms_1_1_base_algorithm_messages.html#a4c5c5ab25f708eff9bdfb57ce8190c0c", null ]
];
var class_distributed_algorithms_1_1_message_window =
[
    [ "PresentedSenderStatus", "class_distributed_algorithms_1_1_message_window.html#a2a57ca07493c1adc0ddf747d1489a0ae", [
      [ "NotFiltered", "class_distributed_algorithms_1_1_message_window.html#a2a57ca07493c1adc0ddf747d1489a0aea2a088f4b27ee06f7fa4403d9543a07c6", null ],
      [ "Filtered", "class_distributed_algorithms_1_1_message_window.html#a2a57ca07493c1adc0ddf747d1489a0aeafe84ed3d6baffd193df85d308e5e908c", null ]
    ] ],
    [ "MessageWindow", "class_distributed_algorithms_1_1_message_window.html#a99eafca090f316e31483664ecd1fd65f", null ],
    [ "PrintDebugMessage", "class_distributed_algorithms_1_1_message_window.html#a4cb9796335bfabc3a98f279c89a72da8", null ],
    [ "Button_Reset_Click", "class_distributed_algorithms_1_1_message_window.html#a3c3b207a57cea134bd1cb7868feea418", null ],
    [ "Button_PresentedSources_List_Click", "class_distributed_algorithms_1_1_message_window.html#a42ed933287d5d2f606369253ea6a9fbd", null ],
    [ "Button_CancelPresentedSourcesFilter_Click", "class_distributed_algorithms_1_1_message_window.html#ab510c0abbb1eed6375d6afeab5d6482c", null ],
    [ "NewPresentedSendersSelected", "class_distributed_algorithms_1_1_message_window.html#af720f9c85aecc0f3a11c44131e65e62a", null ],
    [ "SenderOfItem", "class_distributed_algorithms_1_1_message_window.html#a4964058d3e257121c6c095ab804879bd", null ],
    [ "Button_Filter_And_Click", "class_distributed_algorithms_1_1_message_window.html#aa5d1664ce41aa2e929bed3764e2a0138", null ],
    [ "Button_Filter_Or_Click", "class_distributed_algorithms_1_1_message_window.html#a07c2965c805623c419eb75596eb91dc6", null ],
    [ "OnClosing", "class_distributed_algorithms_1_1_message_window.html#aca6e058886bcbbad61c2b8b1de0f2b9a", null ],
    [ "CloseWindow", "class_distributed_algorithms_1_1_message_window.html#a00f2fdec2bf39076d8ca04af8190f5e3", null ],
    [ "presentedSenders", "class_distributed_algorithms_1_1_message_window.html#a4997d1d31cd091bcb8d7cbaf994a95cf", null ],
    [ "presentedSenderStatus", "class_distributed_algorithms_1_1_message_window.html#ab8525ffd888227181fc4e05dc9c4c823", null ],
    [ "filters", "class_distributed_algorithms_1_1_message_window.html#a8b2330c3d1e5c4702a068940f679b1e8", null ],
    [ "mainWindow", "class_distributed_algorithms_1_1_message_window.html#a0bb66e4ad93c2664563c676096e26236", null ]
];
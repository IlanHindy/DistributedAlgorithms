var class_distributed_algorithms_1_1_new_value_control_prms =
[
    [ "inputFieldType", "class_distributed_algorithms_1_1_new_value_control_prms.html#aeb70b1c6cdaf44ca65b80d34aeeb0820", null ],
    [ "enable", "class_distributed_algorithms_1_1_new_value_control_prms.html#a5bfe2f3d59abe665786a1aabb009f26f", null ],
    [ "options", "class_distributed_algorithms_1_1_new_value_control_prms.html#a655cb67abf97339d07daf9feba94436e", null ],
    [ "value", "class_distributed_algorithms_1_1_new_value_control_prms.html#a3cde8e146d5103203534b107fc5f945f", null ],
    [ "button_click", "class_distributed_algorithms_1_1_new_value_control_prms.html#a4ff9721e2020b81cfb9af0782d16b224", null ],
    [ "addAttributeMethod", "class_distributed_algorithms_1_1_new_value_control_prms.html#a00fbe3b7b496c3ba40f14906e611dc1e", null ],
    [ "Value", "class_distributed_algorithms_1_1_new_value_control_prms.html#aaa02f35d8d4bd17e691b7ba620f8170a", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m =
[
    [ "marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#af7399c1bef39f8205c0cbebc189977ea", null ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#a45259b5d7c895c2d28c8a6cd7942749e", null ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35", [
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ],
    [ "marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#af7399c1bef39f8205c0cbebc189977ea", null ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#a45259b5d7c895c2d28c8a6cd7942749e", null ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35", [
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a0235c996b43b3799573658df41ef82f2", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1m.html#ac994a26ff7555b6cdb591c7175dc9f35a024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ]
];
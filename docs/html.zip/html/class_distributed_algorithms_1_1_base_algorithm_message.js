var class_distributed_algorithms_1_1_base_algorithm_message =
[
    [ "Comps", "class_distributed_algorithms_1_1_base_algorithm_message.html#a50ca3ef5146b9582f542cade21dbb45c", [
      [ "Type", "class_distributed_algorithms_1_1_base_algorithm_message.html#a50ca3ef5146b9582f542cade21dbb45caa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Name", "class_distributed_algorithms_1_1_base_algorithm_message.html#a50ca3ef5146b9582f542cade21dbb45ca49ee3087348e8d44e1feda1917443987", null ],
      [ "Fields", "class_distributed_algorithms_1_1_base_algorithm_message.html#a50ca3ef5146b9582f542cade21dbb45caa4ca5edd20d0b5d502ebece575681f58", null ],
      [ "Targets", "class_distributed_algorithms_1_1_base_algorithm_message.html#a50ca3ef5146b9582f542cade21dbb45ca91fadc5613280f76b916f1fd236e43e9", null ]
    ] ],
    [ "BaseAlgorithmMessage", "class_distributed_algorithms_1_1_base_algorithm_message.html#a44cbd836cca345ab54c6ea374802fe24", null ],
    [ "BaseAlgorithmMessage", "class_distributed_algorithms_1_1_base_algorithm_message.html#a1270f56569372b1090d879bedd264453", null ],
    [ "Send", "class_distributed_algorithms_1_1_base_algorithm_message.html#ac7b617a0c814c3ea87be189e0dc4de88", null ]
];
var class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data =
[
    [ "initiator", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data.html#a67039f9b9558fcf7b7371e848a44cd72", null ],
    [ "parentId", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data.html#af30ee049c537adc95bc5738078d86fcb", null ],
    [ "numberOfChilds", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data.html#a6e37560f61c1e774d145dc36c7eb98b9", null ],
    [ "process", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data.html#a9e8c5cb47ae612522df04e84b18b7762", null ]
];
var class_distributed_algorithms_1_1_source_target_algorithms_select =
[
    [ "SelectResult", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a63b034ba9425179cf470aa480cd2cc75", [
      [ "Quit", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a63b034ba9425179cf470aa480cd2cc75a0d82790b0612935992bd564a17ce37d6", null ],
      [ "Select", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a63b034ba9425179cf470aa480cd2cc75ae0626222614bdee31951d84c64e5e9ff", null ]
    ] ],
    [ "SourceTargetAlgorithmsSelect", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a1d0142deb25f68f711e3ab2fb8f699cc", null ],
    [ "Button_Quit_Click", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#ae77b2daeb22b555e33213e8f5cc527a7", null ],
    [ "Button_Select_Click", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a12f9137f7ae16b2109be7639a78fb8be", null ],
    [ "Selection_SourceSubject_SelectionChanged", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a7f957f88944d144e4fe7f49834a77616", null ],
    [ "Selection_SourceAlgorithm_SelectionChanged", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a30d62bdbecb86321cc88d1a00b832615", null ],
    [ "Selection_TargetSubject_SelectionChanged", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#ac886c0aa892db90fe93fc598c4b9a5cf", null ],
    [ "Selection_TargetSubject_NewItemCreated", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a150e80a652cc869671a4089646571eda", null ],
    [ "result", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a455dcb02d803d31642486146c18af348", null ],
    [ "data", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a5afe3632ceb62aad41ce57a585d28275", null ],
    [ "selectResults", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a47c95864ef346699d2ed0fa4f330845a", null ],
    [ "replaceUserCodeFiles", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#a4b216fdf71fb5063b64a4837a495fd7b", null ],
    [ "newAlgorithm", "class_distributed_algorithms_1_1_source_target_algorithms_select.html#ad2026e9f4dda5456bd0c30bef1f712bb", null ]
];
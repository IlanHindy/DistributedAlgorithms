var class_distributed_algorithms_1_1_permissions =
[
    [ "PermitionTypes", "class_distributed_algorithms_1_1_permissions.html#a4243a34c2882d5509b93ec523fb885c9", [
      [ "Set", "class_distributed_algorithms_1_1_permissions.html#a4243a34c2882d5509b93ec523fb885c9a5d5b78699e57104f2fa03bbdf7b9197b", null ],
      [ "AddRemove", "class_distributed_algorithms_1_1_permissions.html#a4243a34c2882d5509b93ec523fb885c9ada2e4e2a9460c42723da3dc580cbd210", null ],
      [ "Clear", "class_distributed_algorithms_1_1_permissions.html#a4243a34c2882d5509b93ec523fb885c9adc30bc0c7914db5918da4263fce93ad2", null ]
    ] ],
    [ "Permissions", "class_distributed_algorithms_1_1_permissions.html#a8001a6c7f210b9d1f2602b5b46fcf09f", null ],
    [ "Permissions", "class_distributed_algorithms_1_1_permissions.html#ae9a3ac2c7fbd2f9c8be244a853b24388", null ],
    [ "Permissions", "class_distributed_algorithms_1_1_permissions.html#a3136ade58efbe625bec63c309fada55f", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#a23829461395a23ae4aa73161c01881b9", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#a914a0eeab5c2c8d950facb2b6ea3a8f0", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#a5ed235a92818e129bbee6479168163f6", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#a8a6783f1c70da6ba90cfd9939736c745", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#ae82de654597697731d10cf19b67e3bd4", null ],
    [ "Set", "class_distributed_algorithms_1_1_permissions.html#aa3e3f49071e98979a2f716bfb448c6d6", null ],
    [ "CheckPermition", "class_distributed_algorithms_1_1_permissions.html#a53e55d398d9f4c2c843ab251d4815b95", null ],
    [ "IsWindowPresented", "class_distributed_algorithms_1_1_permissions.html#add002483079972e50f599bb31d3d8e18", null ],
    [ "ToString", "class_distributed_algorithms_1_1_permissions.html#ad3896578431303dab877bbd85bd0725c", null ],
    [ "Equals", "class_distributed_algorithms_1_1_permissions.html#ac6e24977d7a68475c605f1e51d4c3dcf", null ],
    [ "numPhases", "class_distributed_algorithms_1_1_permissions.html#aa481b0eb700f05121698c19b225f87b5", null ],
    [ "numPermitionTypes", "class_distributed_algorithms_1_1_permissions.html#ab5cb14e8a1f8c4ab179ada31cc46180f", null ],
    [ "permissions", "class_distributed_algorithms_1_1_permissions.html#ad65010df88f643e9a279a1d6c2d388fe", null ],
    [ "dictionary", "class_distributed_algorithms_1_1_permissions.html#a5b5fdfc1b7699e122f6952fbc7d803dc", null ],
    [ "Data", "class_distributed_algorithms_1_1_permissions.html#a6533671eaf51dd6ef6c7da736e3db91c", null ]
];
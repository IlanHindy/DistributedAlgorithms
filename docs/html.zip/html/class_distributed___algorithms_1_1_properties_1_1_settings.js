var class_distributed___algorithms_1_1_properties_1_1_settings =
[
    [ "defaultInstance", "class_distributed___algorithms_1_1_properties_1_1_settings.html#a5e7efa1156ffadceda3e292e4fe61560", null ],
    [ "Default", "class_distributed___algorithms_1_1_properties_1_1_settings.html#ade15553ea7a05ce454dcdf2b5a80a022", null ]
];
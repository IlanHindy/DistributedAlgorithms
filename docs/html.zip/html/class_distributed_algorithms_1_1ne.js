var class_distributed_algorithms_1_1ne =
[
    [ "eak", "class_distributed_algorithms_1_1ne.html#a4f419a9f127a03f28bb30f91dd13640c", [
      [ "Edited", "class_distributed_algorithms_1_1ne.html#a4f419a9f127a03f28bb30f91dd13640ca67ed6ddb7d890b23166c1bef771e9451", null ],
      [ "Type", "class_distributed_algorithms_1_1ne.html#a4f419a9f127a03f28bb30f91dd13640caa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Id", "class_distributed_algorithms_1_1ne.html#a4f419a9f127a03f28bb30f91dd13640ca490aa6e856ccf208a054389e47ce0d06", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1ne.html#a15774300facdca7ba4f753595a34d9f3", null ],
    [ "opk", "class_distributed_algorithms_1_1ne.html#a8ca71f8aca23fa8a8e1c7abf93ca8844", null ],
    [ "ork", "class_distributed_algorithms_1_1ne.html#a638ac35987b0f17bdca4197c58d23ea0", null ]
];
var class_distributed_algorithms_1_1_breakpoint_1_1_parameters =
[
    [ "parameter1", "class_distributed_algorithms_1_1_breakpoint_1_1_parameters.html#a44fc7fb79e791773b56b21d62476ecca", null ],
    [ "parameter2", "class_distributed_algorithms_1_1_breakpoint_1_1_parameters.html#a409b393b84fa78777d25426f6bd6c0a7", null ]
];
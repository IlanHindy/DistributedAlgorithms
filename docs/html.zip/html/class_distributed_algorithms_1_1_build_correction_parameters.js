var class_distributed_algorithms_1_1_build_correction_parameters =
[
    [ "ErrorMessage", "class_distributed_algorithms_1_1_build_correction_parameters.html#a5dfca046ae9d002ee5913f4f34616838", null ],
    [ "CorrectionMethod", "class_distributed_algorithms_1_1_build_correction_parameters.html#acb6ad4197d85c45b6595efb2db6b9101", null ],
    [ "CorrectionParameters", "class_distributed_algorithms_1_1_build_correction_parameters.html#ac06164329706c6ac52623f3c28f1bc88", null ]
];
var class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms =
[
    [ "existingKeys", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#ab1bc62b0d96705c0edf7ffc94f269ece", null ],
    [ "enableEditableCheckBox", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#a4014a18cde8df9da48a1bdb9b14c1f34", null ],
    [ "enableElementWindowPrmsSelect", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#a266d86ce03c1de62bd90a41b0e80c0a8", null ],
    [ "enableEndInputOperationsSelect", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#a9dfeecb7da0a8936383870b34ba77598", null ],
    [ "attributeTypes", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#adfe6eea7fa30501e74d1a3e12abcc0ec", null ],
    [ "createKey", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#ad5289438e2aa9d8e178ef76e2b47d903", null ],
    [ "keyCategories", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#a29864e9198da9ab06a546b4e81aad5db", null ],
    [ "keyTypes", "class_distributed_algorithms_1_1_create_attribute_dialog_1_1_prms.html#a9f898950f28a9bf1b7e42e69997bb21c", null ]
];
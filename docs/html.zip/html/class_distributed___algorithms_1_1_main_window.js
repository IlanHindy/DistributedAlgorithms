var class_distributed___algorithms_1_1_main_window =
[
    [ "MainWindow", "class_distributed___algorithms_1_1_main_window.html#a931534d5ac3ed8cabb245f64553a442a", null ]
];
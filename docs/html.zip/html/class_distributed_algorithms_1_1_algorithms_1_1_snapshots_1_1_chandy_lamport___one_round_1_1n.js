var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319a34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319a34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#a89007eee44542c7ae790b859fbaae61c", null ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319a34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#aca49a99b67d471244ec44409bcd96319a34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1n.html#a89007eee44542c7ae790b859fbaae61c", null ]
];
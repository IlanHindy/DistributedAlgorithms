var class_distributed_algorithms_1_1_change_message_order =
[
    [ "Comps", "class_distributed_algorithms_1_1_change_message_order.html#a7e7301461ae05e3f2756c6a398c7a14b", [
      [ "SourceProcess", "class_distributed_algorithms_1_1_change_message_order.html#a7e7301461ae05e3f2756c6a398c7a14bac918d99b6ac79ecd9edcda4985a52850", null ],
      [ "Permutations", "class_distributed_algorithms_1_1_change_message_order.html#a7e7301461ae05e3f2756c6a398c7a14ba687883d0478f7377a01db0003294c174", null ],
      [ "MessageQ", "class_distributed_algorithms_1_1_change_message_order.html#a7e7301461ae05e3f2756c6a398c7a14ba94b23b5b63628e06dd987fdbd656a522", null ]
    ] ],
    [ "RecordOrderChange", "class_distributed_algorithms_1_1_change_message_order.html#aadbf7d09dc09cfc5df8250b270b03651", null ],
    [ "CheckAndChange", "class_distributed_algorithms_1_1_change_message_order.html#adaf8824a2eaaa4bd2cd43b77a9408ba6", null ],
    [ "PerformQuestion", "class_distributed_algorithms_1_1_change_message_order.html#a4022a7ca3ea504b022ec25ba6df99652", null ],
    [ "PermutationString", "class_distributed_algorithms_1_1_change_message_order.html#ad5690fc4ca8ed12780d24011b938c87e", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m =
[
    [ "wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3", [
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3a30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3a30269022e9d8f51beaabb52e5d0de2b7", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719d", [
      [ "Wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719dad911b34823c7674c292556dc56148c27", null ],
      [ "Wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719dad911b34823c7674c292556dc56148c27", null ]
    ] ],
    [ "wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3", [
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3a30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#ac197b19de605f4379f69a6e5a3ad09c3a30269022e9d8f51beaabb52e5d0de2b7", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719d", [
      [ "Wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719dad911b34823c7674c292556dc56148c27", null ],
      [ "Wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_1_1m.html#a649f5baf8305f24a9004a3649357719dad911b34823c7674c292556dc56148c27", null ]
    ] ]
];
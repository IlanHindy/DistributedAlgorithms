var class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m =
[
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a56b270481016269164bcfe29e577c44f", null ],
    [ "algorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a88544bcc06a5c98c7ffdae9c482efd1e", null ],
    [ "message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973", [
      [ "PrevAttr", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973ae3692847b116a81c4af5bb350494bf35", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "PrevAttr", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973ae3692847b116a81c4af5bb350494bf35", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973a67f6274e0ac0bd892f9b1ec09a2253fc", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27b", [
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "AlgorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba43face2415e849ca070fafa1fb898f14", null ],
      [ "Message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba86461527178884b100f650fd417ed936", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "AlgorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba43face2415e849ca070fafa1fb898f14", null ],
      [ "Message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba86461527178884b100f650fd417ed936", null ]
    ] ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a56b270481016269164bcfe29e577c44f", null ],
    [ "algorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a88544bcc06a5c98c7ffdae9c482efd1e", null ],
    [ "message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973", [
      [ "PrevAttr", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973ae3692847b116a81c4af5bb350494bf35", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "PrevAttr", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973ae3692847b116a81c4af5bb350494bf35", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a4fc2ce59318d4952121711042efc0973a67f6274e0ac0bd892f9b1ec09a2253fc", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27b", [
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "AlgorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba43face2415e849ca070fafa1fb898f14", null ],
      [ "Message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba86461527178884b100f650fd417ed936", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "AlgorithmMessage", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba43face2415e849ca070fafa1fb898f14", null ],
      [ "Message1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1m.html#a6aaaa9987addd20ffa90a72ffe02c27ba86461527178884b100f650fd417ed936", null ]
    ] ]
];
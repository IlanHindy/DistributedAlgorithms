var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a96cac2f55fef125ee23b6cf1e869a5ac", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9", [
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9a46a2a41cc6e552044816a2d04634545d", null ],
      [ "Marked", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9ab80c545ea15439f0b585c86a6aab3226", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9a46a2a41cc6e552044816a2d04634545d", null ],
      [ "Marked", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9ab80c545ea15439f0b585c86a6aab3226", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a96cac2f55fef125ee23b6cf1e869a5ac", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9", [
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9a46a2a41cc6e552044816a2d04634545d", null ],
      [ "Marked", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9ab80c545ea15439f0b585c86a6aab3226", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9a46a2a41cc6e552044816a2d04634545d", null ],
      [ "Marked", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport___one_round_1_1c.html#a4d29c10b7ca2c7c6e23db045d3121bf9ab80c545ea15439f0b585c86a6aab3226", null ]
    ] ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp =
[
    [ "eak", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5", [
      [ "Initiator", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5a4bd7c2ff07dcc66801a9368957d4bff8", null ],
      [ "Name", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5a49ee3087348e8d44e1feda1917443987", null ],
      [ "Background", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5aa9ded1e5ce5d75814730bb4caaf49419", null ],
      [ "TextColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5aa055cffe44a2aae1849e81f6647fa9df", null ],
      [ "TestListOfAttributes", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5a9d239b81f8f2553065340717bfe53566", null ],
      [ "Breakpoints", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ae5e4d565cd4b92f5265f0e6dc0c3afe5ad19dc64c372f09800d8117286c3d0aff", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a9d5991d05c685b87a1ad741ce538a444", null ],
    [ "opk", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ac49440e31e36a3bcb65a6ada07d3cf01", [
      [ "Breakpoints", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ac49440e31e36a3bcb65a6ada07d3cf01ad19dc64c372f09800d8117286c3d0aff", null ],
      [ "InternalEvents", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ac49440e31e36a3bcb65a6ada07d3cf01a70151ca439c7992ccd31a885b7cb022e", null ],
      [ "BaseAlgorithm", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ac49440e31e36a3bcb65a6ada07d3cf01a6eb47619b0119c1618a57d1391f2e62b", null ],
      [ "ChangeOrderEvents", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#ac49440e31e36a3bcb65a6ada07d3cf01a5305dab734618e6fe3d2a93e93d38aa3", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942", [
      [ "ReceivePort", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942a9f00eafec80c2359b8ccd58a92e7c085", null ],
      [ "TerminationStatus", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942a3936674431d3352ce1bc25fee09331ac", null ],
      [ "MessageQ", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942a94b23b5b63628e06dd987fdbd656a522", null ],
      [ "MessageToBeSentInInit", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942a9ddde13b9a82f0b218a2f336d3b66f65", null ],
      [ "Round", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a30c24ce7f64903a47addbdb9bba4d942ab7f41fc1412ad2ee75e9b2635d3b9d5c", null ]
    ] ],
    [ "ppk", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4ae", [
      [ "FrameColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeae146915a23e3fb6d78a1d9fa63633be6", null ],
      [ "FrameHeight", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeaeaa7cdea3cf1bd6e3521d0838455f48b", null ],
      [ "FrameWidth", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea54932a91154ec7733d72a0ae0d215b64", null ],
      [ "FrameLeft", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea9273c4496262074dea49a5c04aee27da", null ],
      [ "FrameTop", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea6c25d24ad5768f1bce075f2b5d19f71f", null ],
      [ "FrameLineWidth", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea8858ccf425e67571d6ba06b32a082784", null ],
      [ "Background", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeaa9ded1e5ce5d75814730bb4caaf49419", null ],
      [ "Foreground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea45bd1d5b32931106efbf1a82fe6a732f", null ],
      [ "Text", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea9dffbf69ffba8bc38bc4e01abf4b1675", null ],
      [ "BreakpointsFrameColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aea6dcc1c4e89f334713b397c5dae955222", null ],
      [ "BreakpointsFrameWidth", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeac4ebaaf1f2f9bb253c4085c74af2e8d4", null ],
      [ "BreakpointsBackground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeaf554eb7eda20518542e1de74fb706989", null ],
      [ "BreakpointsForeground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bp.html#a40dddc304f1d34f2ac1277ecfec7b4aeac9afa4fdb4d3b2682230bcb6028f5f9f", null ]
    ] ]
];
var class_distributed_algorithms_1_1_file_select =
[
    [ "SelectSource", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439a", [
      [ "New", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aa03c2e7e41ffc181a4e84080b4710e81e", null ],
      [ "Open", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aac3bf447eabe632720a3aa1a7ce401274", null ],
      [ "Save", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aac9cc8cce247e49bae79f15173ce97354", null ],
      [ "SaveAs", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aa3b9b4779908311c49e2126ca7e8ac8b3", null ],
      [ "Debug", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aaa603905470e2a5b8c13e96b579ef0dba", null ],
      [ "Log", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aace0be71e33226e4c1db2bcea5959f16b", null ],
      [ "SaveDebug", "class_distributed_algorithms_1_1_file_select.html#ae0d68c73e281ef6122ba7de49721439aab7c9002318a3ffb938fb26a3346762f2", null ]
    ] ],
    [ "Data", "class_distributed_algorithms_1_1_file_select.html#a2d4c3142a19ea0325fb5300b4f95a1c4", [
      [ "Subject", "class_distributed_algorithms_1_1_file_select.html#a2d4c3142a19ea0325fb5300b4f95a1c4ac7892ebbb139886662c6f2fc8c450710", null ],
      [ "Algorithm", "class_distributed_algorithms_1_1_file_select.html#a2d4c3142a19ea0325fb5300b4f95a1c4a4afa80e77a07f7488ce4d1bdd8c4977a", null ],
      [ "Network", "class_distributed_algorithms_1_1_file_select.html#a2d4c3142a19ea0325fb5300b4f95a1c4aeec89088ee408b80387155272b113256", null ],
      [ "File", "class_distributed_algorithms_1_1_file_select.html#a2d4c3142a19ea0325fb5300b4f95a1c4a0b27918290ff5323bea1e3b78a9cf04e", null ]
    ] ],
    [ "SelectResult", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735", [
      [ "Quit", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735a0d82790b0612935992bd564a17ce37d6", null ],
      [ "Cancel", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735aea4788705e6873b424c65e91c2846b19", null ],
      [ "Open", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735ac3bf447eabe632720a3aa1a7ce401274", null ],
      [ "New", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735a03c2e7e41ffc181a4e84080b4710e81e", null ],
      [ "Save", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735ac9cc8cce247e49bae79f15173ce97354", null ],
      [ "Debug", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735aa603905470e2a5b8c13e96b579ef0dba", null ],
      [ "Log", "class_distributed_algorithms_1_1_file_select.html#a40af951648217bd88592f705916b2735ace0be71e33226e4c1db2bcea5959f16b", null ]
    ] ],
    [ "FileSelect", "class_distributed_algorithms_1_1_file_select.html#aaed6646cedd5cf6be4b348d320a87c09", null ],
    [ "ListStr", "class_distributed_algorithms_1_1_file_select.html#adbb897769a5e1630c1cf519b26488b67", null ],
    [ "ListFiles", "class_distributed_algorithms_1_1_file_select.html#a071d7d506544735252d57a9d6b4a78ba", null ],
    [ "Button_Quit_Click", "class_distributed_algorithms_1_1_file_select.html#a4ebfc1df74684706e4a577a3ab3d9238", null ],
    [ "Button_Select_Click", "class_distributed_algorithms_1_1_file_select.html#af599d27ce069f517b11f3694e63f32bc", null ],
    [ "EndSelectionForNew", "class_distributed_algorithms_1_1_file_select.html#a1df6983adee67a52a79de1363f3b5c57", null ],
    [ "EndSelectionForOpen", "class_distributed_algorithms_1_1_file_select.html#a8d240f9346f77984cdadb2cf24f24336", null ],
    [ "EndSelectionForSaveAs", "class_distributed_algorithms_1_1_file_select.html#a6e8e0db3ac184ec8ca3a1559aa06e191", null ],
    [ "EndSelectionForDebug", "class_distributed_algorithms_1_1_file_select.html#ac496544f14db98bbf95289db010633d4", null ],
    [ "Selection_Subject_SelectionChanged", "class_distributed_algorithms_1_1_file_select.html#af80985b66065caf129b90f8d761641ee", null ],
    [ "Selection_Algorithm_SelectionChanged", "class_distributed_algorithms_1_1_file_select.html#afa4f3077d586c39a37a072ab22f5ce04", null ],
    [ "Selection_Network_SelectionChanged", "class_distributed_algorithms_1_1_file_select.html#a1f25f2f7f4eb5eb10c468fa170500f47", null ],
    [ "Selection_Network_NewItemSelected", "class_distributed_algorithms_1_1_file_select.html#a79881aee681b961592eff72987c5f117", null ],
    [ "result", "class_distributed_algorithms_1_1_file_select.html#a7dbd3eb6cede6c34e3f634d9907c94f3", null ],
    [ "data", "class_distributed_algorithms_1_1_file_select.html#a729ce824486f0617ac0020cba64d610c", null ],
    [ "selectResults", "class_distributed_algorithms_1_1_file_select.html#af9616e2031322dc6893ce56ee10490ff", null ],
    [ "inInit", "class_distributed_algorithms_1_1_file_select.html#af81b47e24eb06b7139febc077012402c", null ],
    [ "selectSource", "class_distributed_algorithms_1_1_file_select.html#a60d5e16da7ee394641ef493bea998d7a", null ],
    [ "fileExtension", "class_distributed_algorithms_1_1_file_select.html#a1c910c110a892eb0e832b486a5857702", null ],
    [ "pathKey", "class_distributed_algorithms_1_1_file_select.html#a8f52f2caf5f5916df562f6c547fedb11", null ],
    [ "filesKey", "class_distributed_algorithms_1_1_file_select.html#a9c27df3143e14e7063396c6db1673730", null ],
    [ "selectedFileKey", "class_distributed_algorithms_1_1_file_select.html#a146f428a5126857b112ba9fae3b2e1bf", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m =
[
    [ "presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1", [
      [ "NumMsg", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1aa22c611536bf46d18178f108de67e4d9", null ],
      [ "NumMsg", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1aa22c611536bf46d18178f108de67e4d9", null ]
    ] ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902", [
      [ "Flag", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902ac5836008c1649301e29351a55db8f65c", null ],
      [ "Message", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902a4c2a8fe7eaf24721cc7a9f0175115bd4", null ],
      [ "Flag", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902ac5836008c1649301e29351a55db8f65c", null ],
      [ "Message", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902a4c2a8fe7eaf24721cc7a9f0175115bd4", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2", [
      [ "Presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2aa53af846b0c37c8788f3db78f4248d94", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2a024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2aa53af846b0c37c8788f3db78f4248d94", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2a024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ],
    [ "presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1", [
      [ "NumMsg", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1aa22c611536bf46d18178f108de67e4d9", null ],
      [ "NumMsg", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a80b6db2085d059099dc83e7435de20e1aa22c611536bf46d18178f108de67e4d9", null ]
    ] ],
    [ "baseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902", [
      [ "Flag", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902ac5836008c1649301e29351a55db8f65c", null ],
      [ "Message", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902a4c2a8fe7eaf24721cc7a9f0175115bd4", null ],
      [ "Flag", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902ac5836008c1649301e29351a55db8f65c", null ],
      [ "Message", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a925c42ab352be0671a28da4f23996902a4c2a8fe7eaf24721cc7a9f0175115bd4", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2", [
      [ "Presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2aa53af846b0c37c8788f3db78f4248d94", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2a024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2aa53af846b0c37c8788f3db78f4248d94", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1m.html#a15dfc4c500a66e91a79e36bb4b8979c2a024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ]
];
var class_distributed_algorithms_1_1_message_box_element_data =
[
    [ "MessageBoxElementData", "class_distributed_algorithms_1_1_message_box_element_data.html#ab231681fa292db79cf950ebf2f6c81c4", null ],
    [ "font", "class_distributed_algorithms_1_1_message_box_element_data.html#a0e7d8adb863200e472e6fed960362c9b", null ],
    [ "label", "class_distributed_algorithms_1_1_message_box_element_data.html#a078d5b25d74dc8e9c2874903be4b3fc6", null ]
];
var class_distributed_algorithms_1_1_word_document_holder =
[
    [ "FileTypes", "class_distributed_algorithms_1_1_word_document_holder.html#a89eaa40b1a990685151d68ed282eda10", [
      [ "Source", "class_distributed_algorithms_1_1_word_document_holder.html#a89eaa40b1a990685151d68ed282eda10af31bbdd1b3e85bccd652680e16935819", null ],
      [ "Temp", "class_distributed_algorithms_1_1_word_document_holder.html#a89eaa40b1a990685151d68ed282eda10a9a438bd942f1f19e6a641028bcfb43ff", null ],
      [ "Document", "class_distributed_algorithms_1_1_word_document_holder.html#a89eaa40b1a990685151d68ed282eda10a0945359809dad1fbf3dea1c95a0da951", null ],
      [ "PseudoCode", "class_distributed_algorithms_1_1_word_document_holder.html#a89eaa40b1a990685151d68ed282eda10a5983519cb3771c3eb8566fa510e9c5ab", null ]
    ] ],
    [ "OpenWordDocument", "class_distributed_algorithms_1_1_word_document_holder.html#a5e2bd00bd72e6f611e9758f7c01b5ea2", null ],
    [ "CloseWordDocument", "class_distributed_algorithms_1_1_word_document_holder.html#a25348b02f6490ff8ecbcc5b02f274778", null ],
    [ "CloseAllWordDocuments", "class_distributed_algorithms_1_1_word_document_holder.html#a320370bf4c1cc2427d9d939118d063e3", null ],
    [ "RetrieveOpenedDocument", "class_distributed_algorithms_1_1_word_document_holder.html#ae1d8322b42b8d19fee31eb498efe1ee9", null ],
    [ "ApplicationExists", "class_distributed_algorithms_1_1_word_document_holder.html#ac535ec81d639b9d0a00ecc6a73ca3de3", null ],
    [ "QuitApplication", "class_distributed_algorithms_1_1_word_document_holder.html#a5d11860f71872f092cbe6f5eb4dff5f1", null ],
    [ "openDocuments", "class_distributed_algorithms_1_1_word_document_holder.html#a390e0295671a1813afbb0976db15c789", null ],
    [ "wordApplication", "class_distributed_algorithms_1_1_word_document_holder.html#ab7000f9be5e2879faa67feeb89cdd6b8", null ],
    [ "filesByType", "class_distributed_algorithms_1_1_word_document_holder.html#a7a4b509f61f65652ffbe50880f1a187a", null ],
    [ "WordApplication", "class_distributed_algorithms_1_1_word_document_holder.html#a6fd4c8efcc641c9fbc01ca09832064f5", null ]
];
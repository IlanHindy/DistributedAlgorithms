var class_distributed_algorithms_1_1_test =
[
    [ "Test", "class_distributed_algorithms_1_1_test.html#a32a757539f55833dd622528ab63737d6", null ],
    [ "Button_OpenWordDocument_Click", "class_distributed_algorithms_1_1_test.html#a05a688976cb36c6b88ae5f197a63242b", null ],
    [ "Button_CloseWordDocument_Click", "class_distributed_algorithms_1_1_test.html#a2270b1c7873d283dbffd85384c00dbec", null ],
    [ "Button_TOC_Click", "class_distributed_algorithms_1_1_test.html#aaeb08580fcc0040c0e6fdfb780fb8709", null ],
    [ "Button_EnumType_Click", "class_distributed_algorithms_1_1_test.html#ae75fe53e777c79d60e793c2e6a2bb255", null ],
    [ "Button_GridView_Click", "class_distributed_algorithms_1_1_test.html#a06b1e5600979e9724a03d392eea9de0c", null ],
    [ "Button_DisableTest_Click", "class_distributed_algorithms_1_1_test.html#aaed2339d8792756617fb8a687db8a587", null ],
    [ "Button_DisableTest_LostFocus", "class_distributed_algorithms_1_1_test.html#ad177a5a919dec475d58facb843006c26", null ],
    [ "wordFilePath", "class_distributed_algorithms_1_1_test.html#aeb59ccafea8e2e12897a97518654d40f", null ],
    [ "wordFileName", "class_distributed_algorithms_1_1_test.html#ae3684213542e9bdf575c3a22f33da9b3", null ],
    [ "application", "class_distributed_algorithms_1_1_test.html#a322f3465c09c2f8097ce56be41f27d40", null ],
    [ "tmpDocument", "class_distributed_algorithms_1_1_test.html#a85d1641752834614e921c37ff27d6104", null ]
];
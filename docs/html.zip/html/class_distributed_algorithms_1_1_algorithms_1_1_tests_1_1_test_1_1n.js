var class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6a", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6aa34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6aa34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a11b749d64f1d9cb5292e473cc076e70a", null ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6a", [
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6aa34b6cd75171affba6957e308dcbd92be", null ],
      [ "Version", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a76c82cac393aa07701933837d7c4fa6aa34b6cd75171affba6957e308dcbd92be", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1n.html#a11b749d64f1d9cb5292e473cc076e70a", null ]
];
var class_distributed_algorithms_1_1_socket_state_object =
[
    [ "SocketStateObject", "class_distributed_algorithms_1_1_socket_state_object.html#a36f831e65ac7cbd3cb96bda237276492", null ],
    [ "SocketStateObject", "class_distributed_algorithms_1_1_socket_state_object.html#a8e9960051e7730e211798deaca89421c", null ],
    [ "workSocket", "class_distributed_algorithms_1_1_socket_state_object.html#a94569dfc9f9edee22fdd346a1a24e497", null ],
    [ "BufferSize", "class_distributed_algorithms_1_1_socket_state_object.html#ab9fa6491874c0771ad6dbc5d27f4f2d0", null ],
    [ "buffer", "class_distributed_algorithms_1_1_socket_state_object.html#a1a3f6481052e440e71cf468e64fec154", null ],
    [ "sb", "class_distributed_algorithms_1_1_socket_state_object.html#a57d2cd4947e8962a27011cd90ea690a2", null ],
    [ "listenSocket", "class_distributed_algorithms_1_1_socket_state_object.html#ad91067db8602568a09ec27d7db6f2b60", null ],
    [ "process", "class_distributed_algorithms_1_1_socket_state_object.html#a2f5affdca6ca5a6876883613288f44b2", null ],
    [ "clientSocket", "class_distributed_algorithms_1_1_socket_state_object.html#aa2d5fe0d3bb265796d49225dfa1b0d0b", null ],
    [ "connectDone", "class_distributed_algorithms_1_1_socket_state_object.html#a2d86750a451168dee1dd23ecea2162f2", null ],
    [ "sendDone", "class_distributed_algorithms_1_1_socket_state_object.html#a14cc23f4811f4b8d35532f17fcf094bf", null ],
    [ "allDone", "class_distributed_algorithms_1_1_socket_state_object.html#a3adf320361ae7b96ce7cd0d8c40b133b", null ]
];
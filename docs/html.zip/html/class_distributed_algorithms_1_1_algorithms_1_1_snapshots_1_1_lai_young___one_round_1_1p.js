var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a9547251e155743bac852b3fb756b450c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3", [
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3addbb78f293dfd6f43cd03ed85ad03286", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3addbb78f293dfd6f43cd03ed85ad03286", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a9547251e155743bac852b3fb756b450c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3", [
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3addbb78f293dfd6f43cd03ed85ad03286", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "Recordered", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1p.html#a867169afbab98a68b91d5be04c1972b3addbb78f293dfd6f43cd03ed85ad03286", null ]
    ] ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc =
[
    [ "eak", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a10191321d7f5bcf4f28f21fba6ea4ac3", [
      [ "SourceProcess", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a10191321d7f5bcf4f28f21fba6ea4ac3ac918d99b6ac79ecd9edcda4985a52850", null ],
      [ "DestProcess", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a10191321d7f5bcf4f28f21fba6ea4ac3a5126c8b154e378d058d695102b7b5e0e", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a0c988faf86c8d099b4796324630e0da8", null ],
    [ "opk", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a36deb83555f74dadbbf79f4f21e937c6", [
      [ "Breakpoints", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a36deb83555f74dadbbf79f4f21e937c6ad19dc64c372f09800d8117286c3d0aff", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a3bbc1f25b4f15f1efbf965916318ec7d", [
      [ "SourcePort", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a3bbc1f25b4f15f1efbf965916318ec7da612e5512186aaa1f9a5f02a8a319c23e", null ],
      [ "DestPort", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a3bbc1f25b4f15f1efbf965916318ec7da43e69beb064eec0db8537968be9c7c74", null ],
      [ "MessageReceived", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a3bbc1f25b4f15f1efbf965916318ec7da714bf4050ed2c6155702085e2566f598", null ],
      [ "TerminationStatus", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a3bbc1f25b4f15f1efbf965916318ec7da3936674431d3352ce1bc25fee09331ac", null ]
    ] ],
    [ "ppk", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840f", [
      [ "LineColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa469a4e660fcd9cde5751506c9c19a3d6", null ],
      [ "HeadColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa90ddfd9d39d8d0006149ee6f9aa6b4e0", null ],
      [ "FrameColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fae146915a23e3fb6d78a1d9fa63633be6", null ],
      [ "FrameWidth", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa54932a91154ec7733d72a0ae0d215b64", null ],
      [ "Background", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840faa9ded1e5ce5d75814730bb4caaf49419", null ],
      [ "Foreground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa45bd1d5b32931106efbf1a82fe6a732f", null ],
      [ "PresentationTxt", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840faad6a16f5974257244faa7fef3e3bcf7a", null ],
      [ "MessagesFrameColor", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa826d3d0ad6526c1c4900dbaaea948eaa", null ],
      [ "MessagesFrameWidth", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa7af2d3af06d19f4cd0133b513cead932", null ],
      [ "MessagesBackground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840fa18f858c3207868158208e2662e57acfe", null ],
      [ "MessagesForeground", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bc.html#a446e5b9ccf3079ae49c4f234be5e840facbfd60dcf138ab9d2a8f767fb47f5231", null ]
    ] ]
];
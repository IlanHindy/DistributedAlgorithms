var class_distributed_algorithms_1_1_log_filters_setting =
[
    [ "LogFiltersSetting", "class_distributed_algorithms_1_1_log_filters_setting.html#a5b6bfa11ce69f9086b9a3e7102894807", null ],
    [ "Button_Save_Click", "class_distributed_algorithms_1_1_log_filters_setting.html#a13a57433c4fb16011d8a033b18508253", null ],
    [ "Button_Remove_Click", "class_distributed_algorithms_1_1_log_filters_setting.html#a3893204d0b1ebd3d1637bc24e0b3d66d", null ],
    [ "Button_Reset_Click", "class_distributed_algorithms_1_1_log_filters_setting.html#a282dfb453fb1016f0d589d43ad641a32", null ],
    [ "Button_Quit_Click", "class_distributed_algorithms_1_1_log_filters_setting.html#aef73e1b14ba058574b5919fd6c91cf1a", null ],
    [ "data", "class_distributed_algorithms_1_1_log_filters_setting.html#a996b6fd7f128178d4f9d7c41a4e8e90b", null ]
];
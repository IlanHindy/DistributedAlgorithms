var class_distributed_algorithms_1_1_select_control_data =
[
    [ "options", "class_distributed_algorithms_1_1_select_control_data.html#a57645bbdc2df08c5fb6ebd0dac21e24a", null ],
    [ "initiallySelected", "class_distributed_algorithms_1_1_select_control_data.html#a171fd8c39a8b01e8579d715886bcd1e0", null ],
    [ "enableItems", "class_distributed_algorithms_1_1_select_control_data.html#a3629e0d9f76ab25d378073bf6fbdb5f6", null ]
];
var class_distributed_algorithms_1_1_syntax_highlight =
[
    [ "TextFragment", "class_distributed_algorithms_1_1_syntax_highlight_1_1_text_fragment.html", "class_distributed_algorithms_1_1_syntax_highlight_1_1_text_fragment" ],
    [ "SyntaxHighlight", "class_distributed_algorithms_1_1_syntax_highlight.html#a25167a2a58dd869903219a0fef7bdfac", null ],
    [ "RemoveHeadingTab", "class_distributed_algorithms_1_1_syntax_highlight.html#adb89af312318127614b6187bc925abe7", null ],
    [ "FromToFragments", "class_distributed_algorithms_1_1_syntax_highlight.html#ad74f244a47ef3af5d5703ddeab94eed5", null ],
    [ "CreateMatchList", "class_distributed_algorithms_1_1_syntax_highlight.html#a57fc2e352f5b73be6cccf527a776e1d9", null ],
    [ "CreateTokensString", "class_distributed_algorithms_1_1_syntax_highlight.html#a19186a965e620d81f10a15c5a3b5c4b5", null ],
    [ "CreateTokens", "class_distributed_algorithms_1_1_syntax_highlight.html#a8909e27f4549eb38790d100b32561de5", null ],
    [ "CreateClassNames", "class_distributed_algorithms_1_1_syntax_highlight.html#a124332d663ff1784b2b2d68b5a88d932", null ],
    [ "CreatePrimitiveTypes", "class_distributed_algorithms_1_1_syntax_highlight.html#a9a47b98151005213f4ef655c785744b6", null ],
    [ "CreateNoHighlight", "class_distributed_algorithms_1_1_syntax_highlight.html#a2471bbabf45b31336a271eb644888f62", null ],
    [ "eol", "class_distributed_algorithms_1_1_syntax_highlight.html#a136d32217f3d3d3cb3f4fe780802420a", null ],
    [ "Text", "class_distributed_algorithms_1_1_syntax_highlight.html#ae267b2cc4efe497eada163ead040d8be", null ],
    [ "FontFamily", "class_distributed_algorithms_1_1_syntax_highlight.html#a889cf1098afe7492edccb799f80e619b", null ],
    [ "FontSize", "class_distributed_algorithms_1_1_syntax_highlight.html#ac1748668e3034e86cbaa29580a82319d", null ],
    [ "FontStyle", "class_distributed_algorithms_1_1_syntax_highlight.html#a2466c3cf66f717c886b54683ce8651f4", null ],
    [ "FontWeight", "class_distributed_algorithms_1_1_syntax_highlight.html#a6978288da2013ad9d2160f5194132430", null ],
    [ "Margin", "class_distributed_algorithms_1_1_syntax_highlight.html#a7706376281ffebe53f3d526884ea01e3", null ],
    [ "HorizontalAlignment", "class_distributed_algorithms_1_1_syntax_highlight.html#ae14f8909e928facfc2ea3893dd8242c3", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process =
[
    [ "PrivateAttributeKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#ad85753018105316ea9a945a97c7a4c4d", [
      [ "MaxRounds", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#ad85753018105316ea9a945a97c7a4c4da1ccdda9414413fb1cffe1aa60dc0b227", null ]
    ] ],
    [ "OperationResultKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40c", [
      [ "Round", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40cab7f41fc1412ad2ee75e9b2635d3b9d5c", null ],
      [ "PrevRoundReportSources", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40ca166a1ca3d7117cb965366dd6dd883b7e", null ],
      [ "CurrentRoundReportSources", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40cadc9ea7198290d393c52f4d69b1a03be9", null ],
      [ "PrevRoundWeight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40ca6ad18c73679c8111a8974fd1879bc1d6", null ],
      [ "CurrentRoundWeight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40caa6b984b84876e99a291e7daf861ef866", null ],
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40ca30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40cad4e2713d1b1725a1592f9268589f990d", null ],
      [ "NetworkSnapshots", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40cabff6d28f9eaec265c4eb433350ed5b2c", null ],
      [ "NetworkSnapshotsMessages", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aaa60ad73bfcb48a1c60a4add881ea40ca14e8647425a1cbd07954e264c3622bb2", null ]
    ] ],
    [ "Init", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a46aca6f0030d605010bf42406c97d4b0", null ],
    [ "Value", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a57b40ee70918467e1393b6e9de5c7024", null ],
    [ "Value", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aa57002b81865980bd574e95e93b6e19a", null ],
    [ "InitBaseAlgorithmData", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#ada3339c00340fa1165c6699c6e02021f", null ],
    [ "LayYoungProcessDefaultAttributeCheck", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a51a4f64f906993ca5e978a7e2088a789", null ],
    [ "CheckBuild", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#adb122aee2b676c7c2b5570766f8cd884", null ],
    [ "CorrectionMethod", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a73048ff493e760c2140ea71a6d6c9c78", null ],
    [ "RunAlgorithm", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a543e8fad90aaf43d7c83571dd4477bca", null ],
    [ "ReceiveHandling", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a134c21874a0718cf73cfe389833f9fe6", null ],
    [ "ArrangeMessageQueue", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a4ba78ac1d1d9d3b1de49536c1c444f10", null ],
    [ "MessageProcessingCondition", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#af76798a3d9d0cf9d469d6ed8f4afd0cd", null ],
    [ "BuildBaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a1c954b628b71a951bb86356e0fb3b1ca", null ],
    [ "HandleBaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a7d83ad9933d4fcf5c1a4ff34259e7e9b", null ],
    [ "HandlePresnpMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#af8d3b7d3949455c4ba41f830692c3f50", null ],
    [ "HandleWeightMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a78252ab15b815c7d72bbf9839e64fecc", null ],
    [ "HandleReportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#af88374ce4f3ac81e2c2617ff6345fd75", null ],
    [ "BeforeSendOperation", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#adc328424eda1c35d82864f4371bf07d0", null ],
    [ "AfterSendOperation", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#abe7f3e0bea7ad6457b4a639e7dd53f8a", null ],
    [ "TakeSnapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a9467962946117374e0171f790fe72b8a", null ],
    [ "SendPresnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#ad0dd6327f2fbc8996271e87fc58a8027", null ],
    [ "ReportHandelingDataStartRound", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#ae1b503ea0fe3729451554a81b4163e4f", null ],
    [ "SendWeight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a0346717fa32e980b9df016d59fbf4206", null ],
    [ "SendReportIfNeeded", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#aa3e243d49ca539610dd2304ba40005e2", null ],
    [ "ShowResults", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a2ad02223bb8eb7ed24625c8147bd8510", null ],
    [ "UpdatePresentation", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a4c2a1febd5f1a7f4ca48b9ec2ea0cec6", null ],
    [ "PresentationText", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a731da510e6a7e0d58ca41a8505599b39", null ],
    [ "ToString", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_process.html#a94f63b943a48740e0ec1771264504a67", null ]
];
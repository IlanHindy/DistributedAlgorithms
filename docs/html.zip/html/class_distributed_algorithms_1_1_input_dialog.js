var class_distributed_algorithms_1_1_input_dialog =
[
    [ "InputDialog", "class_distributed_algorithms_1_1_input_dialog.html#a8befc0fa2365dfd202143ab6f48a6d8c", null ],
    [ "CreateInputField", "class_distributed_algorithms_1_1_input_dialog.html#a84d9bb0e239b2171f2f8855d8a64d1ee", null ],
    [ "GetValue", "class_distributed_algorithms_1_1_input_dialog.html#a5c49e529b3ec2f6b6c6207352506d931", null ],
    [ "Button_OK_Click", "class_distributed_algorithms_1_1_input_dialog.html#a7cf93bea36543bf47c9662dd300e744f", null ],
    [ "Button_Cancel_Click", "class_distributed_algorithms_1_1_input_dialog.html#a1f77796290178c63fe24adb2fcc1a4ed", null ],
    [ "result", "class_distributed_algorithms_1_1_input_dialog.html#a8594be3ed92b1c55bb85d25a6bab13fe", null ]
];
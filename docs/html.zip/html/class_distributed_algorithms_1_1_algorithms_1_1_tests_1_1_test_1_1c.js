var class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5", [
      [ "Cs2", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a27da76d5e752e7b2793a2d1241ce1e3a", null ],
      [ "Cs1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a99b3b4b588062fd65168488acf28fc03", null ],
      [ "Cs2", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a27da76d5e752e7b2793a2d1241ce1e3a", null ],
      [ "Cs1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a99b3b4b588062fd65168488acf28fc03", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74c", [
      [ "Cs3", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74caec1ee14791f2a4b3aab66ff483388708", null ],
      [ "Cs3", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74caec1ee14791f2a4b3aab66ff483388708", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5", [
      [ "Cs2", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a27da76d5e752e7b2793a2d1241ce1e3a", null ],
      [ "Cs1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a99b3b4b588062fd65168488acf28fc03", null ],
      [ "Cs2", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a27da76d5e752e7b2793a2d1241ce1e3a", null ],
      [ "Cs1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a862a88fc14f78e697d60e654a01efbf5a99b3b4b588062fd65168488acf28fc03", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74c", [
      [ "Cs3", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74caec1ee14791f2a4b3aab66ff483388708", null ],
      [ "Cs3", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1c.html#a65a9369bae79fbe421008103bd0db74caec1ee14791f2a4b3aab66ff483388708", null ]
    ] ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message =
[
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#acbb188d0554624384d2f24901c67ebfc", [
      [ "Base", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#acbb188d0554624384d2f24901c67ebfca095a1b43effec73955e31e790438de49", null ],
      [ "Presnp", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#acbb188d0554624384d2f24901c67ebfcaa53af846b0c37c8788f3db78f4248d94", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#acbb188d0554624384d2f24901c67ebfca8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#acbb188d0554624384d2f24901c67ebfca4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ]
    ] ],
    [ "FieldKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6", [
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6ac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "Snapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6ad4e2713d1b1725a1592f9268589f990d", null ],
      [ "SnapshotMessages", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6a5ebca7f1a99cc6e8f68eddab194d0387", null ],
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "BaseMessageRound", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_message.html#abe7de64be97aae2ee51724490b3dd2e6a711df06383aef8db709d5d2f50347273", null ]
    ] ]
];
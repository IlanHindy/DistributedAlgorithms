var data_structures =
[
    [ "DistributedAlgorithms.Attribute", "attribute.html", null ],
    [ "DistributedAlgorithms.AttributeDictionary", "attribute_dictionary.html", null ],
    [ "DistributedAlgorithms.AttributeList", "attribute_list.html", null ]
];
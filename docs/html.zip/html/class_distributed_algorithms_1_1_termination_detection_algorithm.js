var class_distributed_algorithms_1_1_termination_detection_algorithm =
[
    [ "ProcessData", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data.html", "class_distributed_algorithms_1_1_termination_detection_algorithm_1_1_process_data" ],
    [ "MessageSendReport", "class_distributed_algorithms_1_1_termination_detection_algorithm.html#af075114ad09a7843edf0c8f881d60911", null ],
    [ "MessageReceiveReport", "class_distributed_algorithms_1_1_termination_detection_algorithm.html#a62a4321e9e1b4a39d62dee76e6a76748", null ],
    [ "CheckTermination", "class_distributed_algorithms_1_1_termination_detection_algorithm.html#a56ead2e50369da34883edc78002330b0", null ],
    [ "ReportStatus", "class_distributed_algorithms_1_1_termination_detection_algorithm.html#a0f1c94e5e0beb98998ac30294f5ce563", null ],
    [ "processesData", "class_distributed_algorithms_1_1_termination_detection_algorithm.html#ae7de62ddd99e4806172f6d3f3deb4e88", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7", [
      [ "MaxRound", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a3b722196ba99636647477af268d7c516", null ],
      [ "RunGetSetTest", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a9e4299592a9efbd1fe40fa4d74b115bb", null ],
      [ "MaxRound", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a3b722196ba99636647477af268d7c516", null ],
      [ "RunGetSetTest", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a9e4299592a9efbd1fe40fa4d74b115bb", null ]
    ] ],
    [ "ork_testDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a0a904208ffa644e260567eedb8396883", null ],
    [ "ork_testDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a91736af9b7fd8456ffb6d09bf7c1208c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782", [
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "TestList", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a1cd1059868cbdea39cf6c0d61c56c10e", null ],
      [ "TestDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a9c2e65247a0c579942e23d92b3404af5", null ],
      [ "TestNetworkElement", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782afe8bf4638f5328b325148afd6ea30629", null ],
      [ "TestListNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a5c4b9d976d97c7ad46d45149127637a1", null ],
      [ "TestDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a3653f1de595c37c7832ca8078dc0f2bd", null ],
      [ "TestNetworkElementNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a7158514e6437e7d449c4f28a3a997c38", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "TestList", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a1cd1059868cbdea39cf6c0d61c56c10e", null ],
      [ "TestDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a9c2e65247a0c579942e23d92b3404af5", null ],
      [ "TestNetworkElement", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782afe8bf4638f5328b325148afd6ea30629", null ],
      [ "TestListNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a5c4b9d976d97c7ad46d45149127637a1", null ],
      [ "TestDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a3653f1de595c37c7832ca8078dc0f2bd", null ],
      [ "TestNetworkElementNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a7158514e6437e7d449c4f28a3a997c38", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7", [
      [ "MaxRound", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a3b722196ba99636647477af268d7c516", null ],
      [ "RunGetSetTest", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a9e4299592a9efbd1fe40fa4d74b115bb", null ],
      [ "MaxRound", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a3b722196ba99636647477af268d7c516", null ],
      [ "RunGetSetTest", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#ab6b6abc94074cc6b4a09ccc4197dc9d7a9e4299592a9efbd1fe40fa4d74b115bb", null ]
    ] ],
    [ "ork_testDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a0a904208ffa644e260567eedb8396883", null ],
    [ "ork_testDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a91736af9b7fd8456ffb6d09bf7c1208c", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782", [
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "TestList", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a1cd1059868cbdea39cf6c0d61c56c10e", null ],
      [ "TestDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a9c2e65247a0c579942e23d92b3404af5", null ],
      [ "TestNetworkElement", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782afe8bf4638f5328b325148afd6ea30629", null ],
      [ "TestListNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a5c4b9d976d97c7ad46d45149127637a1", null ],
      [ "TestDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a3653f1de595c37c7832ca8078dc0f2bd", null ],
      [ "TestNetworkElementNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a7158514e6437e7d449c4f28a3a997c38", null ],
      [ "S1", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a67f6274e0ac0bd892f9b1ec09a2253fc", null ],
      [ "TestList", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a1cd1059868cbdea39cf6c0d61c56c10e", null ],
      [ "TestDictionary", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a9c2e65247a0c579942e23d92b3404af5", null ],
      [ "TestNetworkElement", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782afe8bf4638f5328b325148afd6ea30629", null ],
      [ "TestListNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a5c4b9d976d97c7ad46d45149127637a1", null ],
      [ "TestDictionaryNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a3653f1de595c37c7832ca8078dc0f2bd", null ],
      [ "TestNetworkElementNotEdittable", "class_distributed_algorithms_1_1_algorithms_1_1_tests_1_1_test_1_1p.html#a5d8825d7c9e8c087969bf4c3a6bfb782a7158514e6437e7d449c4f28a3a997c38", null ]
    ] ]
];
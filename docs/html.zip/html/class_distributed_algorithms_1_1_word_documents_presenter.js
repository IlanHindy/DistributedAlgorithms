var class_distributed_algorithms_1_1_word_documents_presenter =
[
    [ "WordDocumentsPresenter", "class_distributed_algorithms_1_1_word_documents_presenter.html#a86b135be73687573a6f1ce951a3abe32", null ]
];
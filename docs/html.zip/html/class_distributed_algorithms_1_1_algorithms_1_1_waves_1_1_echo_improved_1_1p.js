var class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1p.html#ade540db5aa9c5426d32c97f606f0b9f6", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1p.html#abbab923ad8f09783782b1b92d6eb33fe", [
      [ "Parent", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1p.html#abbab923ad8f09783782b1b92d6eb33fea30269022e9d8f51beaabb52e5d0de2b7", null ],
      [ "Received", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1p.html#abbab923ad8f09783782b1b92d6eb33feaac5bb077c33753116b5e91ff1766e7bc", null ]
    ] ]
];
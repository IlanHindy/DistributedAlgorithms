var class_distributed_algorithms_1_1_asynchronous_sender =
[
    [ "StartSending", "class_distributed_algorithms_1_1_asynchronous_sender.html#a8a5e21871ecfe061fc9b55e4447fc2a5", null ],
    [ "ConnectCallback", "class_distributed_algorithms_1_1_asynchronous_sender.html#aad9b71b7bb5d353dcd469ffa1cf2c73f", null ],
    [ "Send", "class_distributed_algorithms_1_1_asynchronous_sender.html#a5c65e48c005e1a9ac69c3ae1570a5f14", null ],
    [ "SendCallback", "class_distributed_algorithms_1_1_asynchronous_sender.html#adeed01343c5517a2232738d562748337", null ],
    [ "IsSocketConnected", "class_distributed_algorithms_1_1_asynchronous_sender.html#a0528ba1ac17ab314339160648cf711fe", null ]
];
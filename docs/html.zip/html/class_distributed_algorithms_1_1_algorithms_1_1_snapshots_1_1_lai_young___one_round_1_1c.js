var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a6e6a114d5e32fb881a7204a361467a10", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81e", [
      [ "Sent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea7f8c0283f16925caed8e632086b81b9c", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea46a2a41cc6e552044816a2d04634545d", null ],
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81eac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Arrived", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea168d3e51452f6d8988f75ed882e74eb6", null ],
      [ "Sent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea7f8c0283f16925caed8e632086b81b9c", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea46a2a41cc6e552044816a2d04634545d", null ],
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81eac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Arrived", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea168d3e51452f6d8988f75ed882e74eb6", null ]
    ] ],
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a6e6a114d5e32fb881a7204a361467a10", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81e", [
      [ "Sent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea7f8c0283f16925caed8e632086b81b9c", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea46a2a41cc6e552044816a2d04634545d", null ],
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81eac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Arrived", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea168d3e51452f6d8988f75ed882e74eb6", null ],
      [ "Sent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea7f8c0283f16925caed8e632086b81b9c", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea46a2a41cc6e552044816a2d04634545d", null ],
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81eac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Arrived", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lai_young___one_round_1_1c.html#a5e4cafb3a234851cb3eb5183b19cf81ea168d3e51452f6d8988f75ed882e74eb6", null ]
    ] ]
];
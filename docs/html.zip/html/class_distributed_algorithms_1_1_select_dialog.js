var class_distributed_algorithms_1_1_select_dialog =
[
    [ "SelectDialogResult", "class_distributed_algorithms_1_1_select_dialog.html#aeda1e690ed82215802248a1f4f1ec265", [
      [ "Quit", "class_distributed_algorithms_1_1_select_dialog.html#aeda1e690ed82215802248a1f4f1ec265a0d82790b0612935992bd564a17ce37d6", null ],
      [ "Select", "class_distributed_algorithms_1_1_select_dialog.html#aeda1e690ed82215802248a1f4f1ec265ae0626222614bdee31951d84c64e5e9ff", null ]
    ] ],
    [ "SelectDialog", "class_distributed_algorithms_1_1_select_dialog.html#a5c575ae53539ed1f05ed257ce60c19ed", null ],
    [ "Button_Quit_Click", "class_distributed_algorithms_1_1_select_dialog.html#ad061f395d0db316d6a557a383898bcec", null ],
    [ "Button_Select_Click", "class_distributed_algorithms_1_1_select_dialog.html#ad36fc93d916017194d4457d3a87df588", null ],
    [ "ListBox_Options_SelectionChanged", "class_distributed_algorithms_1_1_select_dialog.html#a4527c3b59b311b7c6e2dbb68803da7db", null ],
    [ "Selection", "class_distributed_algorithms_1_1_select_dialog.html#aa04984a187de709987a5ead4105902db", null ],
    [ "SelectionText", "class_distributed_algorithms_1_1_select_dialog.html#a1818af21d6bed8cebff23d88002b074a", null ],
    [ "Result", "class_distributed_algorithms_1_1_select_dialog.html#a7dccdea95a3bbd96fcea5713890260be", null ],
    [ "selectionMode", "class_distributed_algorithms_1_1_select_dialog.html#a7ca977e9c57ba6cf957c423defe1e775", null ]
];
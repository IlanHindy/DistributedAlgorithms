var class_distributed___algorithms_1_1_properties_1_1_resources =
[
    [ "Resources", "class_distributed___algorithms_1_1_properties_1_1_resources.html#ab57d7255762906246af770acfe2dcb55", null ],
    [ "resourceMan", "class_distributed___algorithms_1_1_properties_1_1_resources.html#aecf5b3f4bebea8f2128c0cbace127079", null ],
    [ "resourceCulture", "class_distributed___algorithms_1_1_properties_1_1_resources.html#a7092a7568e7cc7e2d78cb069b67e6498", null ],
    [ "ResourceManager", "class_distributed___algorithms_1_1_properties_1_1_resources.html#a50b3a968864399bf0ecb54891b06da91", null ],
    [ "Culture", "class_distributed___algorithms_1_1_properties_1_1_resources.html#a02e2c12103587e18f10e76627cb67a0f", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel =
[
    [ "PrivateAttributeKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a8964287ae43a30d37a495239fb2729d1", null ],
    [ "OperationResultKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45", [
      [ "Sent", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45a7f8c0283f16925caed8e632086b81b9c", null ],
      [ "Expected", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45ac87076fc9901bb23fee8eda95971b5a5", null ],
      [ "Count", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45ae93f994f01c537c4e2f7d8528c3eb5e9", null ],
      [ "State", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45a46a2a41cc6e552044816a2d04634545d", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45a8c489d0946f66d17d73f26366a4bf620", null ],
      [ "PrevRoundCount", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a51e374b607cecef1d853c48e21fbfc45ad6127a4dbfa76c5633fa993e44b09433", null ]
    ] ],
    [ "LayYoungChannel", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a5ed52aa1cff103976cdd36abd50c2715", null ],
    [ "LayYoungChannel", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a233403df8daa791cedb94502b1074147", null ],
    [ "Init", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#ac1eb26eb7c7efe91ce2167baca822787", null ],
    [ "Value", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a1dc0ccd35b0264e786b58b35eca6f209", null ],
    [ "Value", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a9b462a5348d117bf24607581bf8613b6", null ],
    [ "LayYoungChannelDefaultAttributeCheck", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a39584aef95f05d1918acddc252b71c51", null ],
    [ "CheckBuild", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#af002dd28e45ee1808315369d7d346261", null ],
    [ "CorrectionMethod", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#aa3587ab9242ee9fedff45311083840ec", null ],
    [ "ToString", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a46d6d30e085b8b8396078d9c900ea68e", null ],
    [ "PresentationText", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a6b0b7e5be8c57090b0a1e804ec3dc760", null ],
    [ "FinishedRound", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a618a4db3c0690331bacbdbfaa0765ae2", null ],
    [ "AddToState", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_lay_young_1_1_lay_young_channel.html#a8c91da30399793ec41b43a068bd56f98", null ]
];
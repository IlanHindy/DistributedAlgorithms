var class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1p =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1p.html#a5e14a2cb7b8408c04e6739581868d425", null ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_templates_1_1_template_1_1p.html#ab564d0811f7271dc27102012ec5d2545", null ]
];
var class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm =
[
    [ "pak", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4", [
      [ "MessageType", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4a20b67ff6d86442b20819a3cd48bfc603", null ],
      [ "SourceProcess", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4ac918d99b6ac79ecd9edcda4985a52850", null ],
      [ "SourcePort", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4a612e5512186aaa1f9a5f02a8a319c23e", null ],
      [ "DestProcess", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4a5126c8b154e378d058d695102b7b5e0e", null ],
      [ "DestPort", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4a43e69beb064eec0db8537968be9c7c74", null ],
      [ "Round", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4ab7f41fc1412ad2ee75e9b2635d3b9d5c", null ],
      [ "LogicalClock", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aafb879a9d037de7fae5d6b482834dca4a04d8563bce6c73697329a26aeafd1217", null ]
    ] ],
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495b", [
      [ "NullMessageType", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495baef239966aa6e15df07302210477f06ef", null ],
      [ "EmptyMessage", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495ba986721326eb6745341e77764ba8847d1", null ],
      [ "Terminate", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495ba056fa3d840f48b7bfbbd68c19a4797b3", null ],
      [ "Forewared", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495baabf27ee48027790665edd4a6a919793b", null ],
      [ "Backwared", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495bafd0e5117e6e105cb07142c5a6e887545", null ],
      [ "LastMessage", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495ba518a42e19f7dde0b76c30c4d53998cf6", null ],
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a5bcf8df2487cac5ca22e2757d0e9495ba024b2ac3428eb2074655bbd35b1b9748", null ]
    ] ],
    [ "opk", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aa397f4d883850ee37e42d8c13c880b31", [
      [ "Breakpoints", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#aa397f4d883850ee37e42d8c13c880b31ad19dc64c372f09800d8117286c3d0aff", null ]
    ] ],
    [ "ork", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a26ecf87771f68c4442ba2bc047d6e377", [
      [ "Name", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a26ecf87771f68c4442ba2bc047d6e377a49ee3087348e8d44e1feda1917443987", null ],
      [ "PositionInProcessQ", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a26ecf87771f68c4442ba2bc047d6e377aac8e62b809aae0b3717080837d257a92", null ]
    ] ],
    [ "PrmSource", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a3d5e2a2ff9446fb64eb29f2bbc99325d", [
      [ "MainPrm", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a3d5e2a2ff9446fb64eb29f2bbc99325da5f4ac904b69e03dec0a9eb9a509979e7", null ],
      [ "Default", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a3d5e2a2ff9446fb64eb29f2bbc99325da7a1920d61156abc05a60135aefe8bc67", null ],
      [ "Prms", "class_distributed_algorithms_1_1_algorithms_1_1_base_1_1_base_1_1bm.html#a3d5e2a2ff9446fb64eb29f2bbc99325da9c4fb9cb6a72540612510200435ee217", null ]
    ] ]
];
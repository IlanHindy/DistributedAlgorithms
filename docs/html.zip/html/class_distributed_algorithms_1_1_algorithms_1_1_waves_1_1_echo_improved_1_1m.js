var class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1m =
[
    [ "messageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1m.html#a4fca81eb983ff3ab2792d5f5139bf447", [
      [ "Wave", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1m.html#a4fca81eb983ff3ab2792d5f5139bf447ad911b34823c7674c292556dc56148c27", null ]
    ] ],
    [ "fieldKeys", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1m.html#aa8ca9f8e29cac1b9b4e61e16c841786e", [
      [ "Sender", "class_distributed_algorithms_1_1_algorithms_1_1_waves_1_1_echo_improved_1_1m.html#aa8ca9f8e29cac1b9b4e61e16c841786ea8aace3ec18d83874d22850b7eee93c7d", null ]
    ] ]
];
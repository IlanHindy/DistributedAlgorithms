var class_distributed_algorithms_1_1brp =
[
    [ "ork", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604ef", [
      [ "Name", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa49ee3087348e8d44e1feda1917443987", null ],
      [ "HostingElementType", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa089f971aaf647c3ac426ff68a046cc75", null ],
      [ "Enable", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa2faec1f9f8cc7f8f40d521c4dd574f49", null ],
      [ "Operator", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efae1b3ec89ead7f83a9245ed5c9cacfdbf", null ],
      [ "Parameters", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa3225a10b07f1580f10dee4abc3779e6c", null ],
      [ "IndexInList", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa0f9e4b95b80a3a082eadbf890e538951", null ],
      [ "ListParameterOneOrAll", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa8906c3ab0ef03ec604dab668ddbc39b7", null ],
      [ "ListEvaluationMode", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efaf9046b2fc4e9dbaa0f81002106a3f234", null ],
      [ "LastCheckResult", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efaa8990a0c5d983c94efc32dc7e9d4d8b4", null ],
      [ "LastRunningResult", "class_distributed_algorithms_1_1brp.html#a911263dae6a2ed89aa2d2242b4b604efa0aef9dc834074b48142471a0ab3abb32", null ]
    ] ]
];
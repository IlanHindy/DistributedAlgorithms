var class_distributed_algorithms_1_1_presentation_element =
[
    [ "ControlKeys", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14", [
      [ "ArrowHead", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a36cab6fce958ae676d5e2b8a8045fb25", null ],
      [ "MessageQ", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a94b23b5b63628e06dd987fdbd656a522", null ],
      [ "Circle", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a30954d90085f6eaaf5817917fc5fecb3", null ],
      [ "TextBlock", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14abc4bb2d2fad6e5a8adb545d18a300b78", null ],
      [ "DebugDataLabel", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a04532569d39e550bcc88c48f0566133d", null ],
      [ "DebugDataCanvas", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a0b85bf9876fa26aad3d4a82ea4c5ce27", null ],
      [ "DebugDataButton", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a6e3108ac2af94eb50d703e56e10b53a5", null ],
      [ "BreakpointLabel", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14a303c2e933aa2ce74281144acbdc27f54", null ],
      [ "Label", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14ab021df6aac4654c454f46c77646e745f", null ],
      [ "MessagesGridView", "class_distributed_algorithms_1_1_presentation_element.html#ac116fa31e503072e13c34182faf52b14afb9a12bbb2ba86cb47905c1205059440", null ]
    ] ],
    [ "controls", "class_distributed_algorithms_1_1_presentation_element.html#a2843ac71061287b4b9121289911bf077", null ],
    [ "status", "class_distributed_algorithms_1_1_presentation_element.html#ae8836f9ae11e225921bbd374a09a6085", null ],
    [ "blinkingStoryBoard", "class_distributed_algorithms_1_1_presentation_element.html#a75132ff4ad94c0ac188e53e072605274", null ],
    [ "debugWindow", "class_distributed_algorithms_1_1_presentation_element.html#a7c9acf8e2835c77d92768a59f325a2a2", null ],
    [ "breakpointsVisibility", "class_distributed_algorithms_1_1_presentation_element.html#ab0601aa076aa34b908e346d307731f71", null ]
];
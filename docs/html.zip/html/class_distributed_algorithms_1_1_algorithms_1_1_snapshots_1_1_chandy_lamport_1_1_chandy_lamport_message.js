var class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message =
[
    [ "MessageTypes", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a9916e9b003cbd59687b28e943b55ab0a", [
      [ "BaseMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a9916e9b003cbd59687b28e943b55ab0aa024b2ac3428eb2074655bbd35b1b9748", null ],
      [ "Marker", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a9916e9b003cbd59687b28e943b55ab0aa0235c996b43b3799573658df41ef82f2", null ],
      [ "Report", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a9916e9b003cbd59687b28e943b55ab0aa4b1b4dc8cf38b3c64b1d657da8f5ac8c", null ]
    ] ],
    [ "FieldKeys", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad2936844a1cf1ec92c2f8231012bfe81", [
      [ "Snapshots", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad2936844a1cf1ec92c2f8231012bfe81a9147e5e61a7b9260dec09f3a6eb3e5be", null ],
      [ "MessageSnapshot", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad2936844a1cf1ec92c2f8231012bfe81ae4555109e92bc979eca7595937a709d4", null ],
      [ "Id", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad2936844a1cf1ec92c2f8231012bfe81a490aa6e856ccf208a054389e47ce0d06", null ],
      [ "Weight", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad2936844a1cf1ec92c2f8231012bfe81a8c489d0946f66d17d73f26366a4bf620", null ]
    ] ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a305702fbffdaefbf41696daaf47bce61", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ac4942d488c977556b6f7537069b9e66d", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a4fd16aee75bb1e9c58bfa3e39d2279c5", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a18a5162847477c1bbfcd100339938728", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a498a6e4454e9f58950395227bd3b4381", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a7f3b2367d7453f2e08202e6c1aa8cba0", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a2e5cf4857d0b6578702b56da16b41cc9", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ab211b8ec56bc894e23aa66e35ab487bd", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a3d7d7a295e7cc3b639b7e6e50d26cb79", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#aae3798dbf06be432364e320617bf30f1", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a7e9a16d94c97abec3ecded142215fa65", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a18a5162847477c1bbfcd100339938728", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#afeb212293339b19d91b8f88d9651e3f8", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#a53c6b08c432853f3b8e1e35c10fd227c", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ad96b31db98322fe7d3e1ac858ccbed91", null ],
    [ "ChandyLamportMessage", "class_distributed_algorithms_1_1_algorithms_1_1_snapshots_1_1_chandy_lamport_1_1_chandy_lamport_message.html#ac1e05399f33ae3aaebfb2ef8e4acc964", null ]
];